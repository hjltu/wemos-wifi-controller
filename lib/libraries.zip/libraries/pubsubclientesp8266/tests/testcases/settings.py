server_ip = "172.16.0.2"
arduino_ip = "172.16.0.100"
