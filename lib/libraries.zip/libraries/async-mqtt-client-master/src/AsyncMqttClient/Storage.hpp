#pragma once

namespace AsyncMqttClientInternals {
struct PendingPubRel {
  uint16_t packetId;
};
}  // namespace AsyncMqttClientInternals
